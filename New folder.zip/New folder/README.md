"# newopzonik" 
