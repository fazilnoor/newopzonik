productButton=[
    {
        "class":"Fiber_Optic_Patch_Cable",
        "productName":"Fiber Optic Patch Cable",
    },
    {
    "class":"Multifiber_Pigtails",
    "productName":"Multifiber Pigtails",
    },
    {
    "class":"Fiber_Optic_Adapter",
    "productName":"Fiber Optic Adapter",
    },
    
    {
    "class":"Fiber_Optic_Hybrid_Adapter",
    "productName":"Fiber Optic Hybrid Adapter",
    },
    
    {
    "class":"Fiber_Optic_Attenuators",
    "productName":"Fiber Optic Attenuators",
    },
    {
        "class":"Breakout_Cable",
        "productName":"Breakout Cable",  
    },
    // {
    //     "class":"Distribution_Cable",
    //     "productName":"Distribution Cable",  
    // },
    {
        "class":"Fiber_Optic_Rackmount_Enclosure ",
        "productName":"Fiber Optic Rackmount Enclosure ",  
    },
    {
        "class":"Fiber_Optic_Adapter_Cable",
        "productName":"Fiber Optic Adapter Cable",  
    },
    {
        "class":"Fiber_Optic_Patch_Cable_Armoured",
        "productName":"Fiber Optic Patch Cable Armoured",  
    },
    {
        "class":"Loopback_Adapter_Test_Cable",
        "productName":"Loopback Adapter Test Cable",  
    },
    
                
                
    ]




productImage=[
   //FIBER OPTICS PATCH CABLE .
    {
        "image":"../../public/productImage/Fiber Optic patch cabel/SingleMode SX/LC TO SC.jpg",
        "imageName":"LC TO SC",
        "class":"Fiber_Optic_Patch_Cable",
        "content":"OpZonik LC TO SC Fiber Optic Patch Cable Singlemode Simplex.",
        "productName":"Fiber Optic Patch Cable Singlemode Simplex"
    },
    {
        "image":"../../public/productImage/Fiber Optic patch cabel/SingleMode SX/LC TO LC.jpg",
        "imageName":"LC TO LC",
        "class":"iber_Optic_Patch_Cable",
        "content":"OpZonik LC TO LC Fiber Optic Patch Cable Singlemode Simplex Optical."
    },
    {
        "image":"../../public/productImage/Fiber Optic patch cabel/SingleMode SX/LC TO FC.jpg",
        "imageName":"LC TO FC",
        "class":"Fiber Optic Patch Cable",
        "content":"OpZonik LC TO FC Fiber Optic Patch Cable Singlemode Simplex."
    },
    {
        "image":"../../public/productImage/Fiber Optic patch cabel/SingleMode SX/LC TO ST.jpg",
        "imageName":"LC TO ST",
        "class":"Fiber_Optic_Patch_Cable",
        "content":"OpZonik LC TO ST Fiber Optic Patch Cable Singlemode Simplex."
    },
      
    {
    "image":"../../public/productImage/Fiber Optic patch cabel/SingleMode SX/LCAPC TO SCAPC.jpg",
    "imageName":"LCAPC TO SCAPC",
    "class":"Fiber_Optic_Patch_Cable",
    "content":"OpZonik LCAPC TO SCAPC Fiber Optic Patch Cable Singlemode Simplex."
         },
         {
            "image":"../../public/productImage/Fiber Optic patch cabel/SingleMode SX/SCAPC TO SCAPC.jpg",
            "imageName":"FCAPC TO SCAPC",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik FCAPC TO SCAPC Fiber Optic Patch Cable Singlemode Simplex."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/SingleMode SX/SCAPC TO SC.jpg",
            "imageName":"SCAPC TO SC",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik SCAPC TO SC Fiber Optic Patch Cable Singlemode Simplex."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/SingleMode SX/SCAPC TO FC.jpg",
            "imageName":"FC TO SCAPC",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik  FC TO SCAPC  Fiber Optic Patch Cable Singlemode Simplex."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/SingleMode SX/SCAPC TO ST.jpg",
            "imageName":"SCAPC TO ST",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik SCAPC TO ST Fiber Optic Patch Cable Singlemode Simplex."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/SingleMode SX/SC TO SC.jpg",
            "imageName":"SC TO SC",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik SC TO SC Fiber Optic Patch Cable Singlemode Simplex."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/SingleMode SX/SC TO ST.jpg",
            "imageName":"SC TO ST",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik SC TO ST Fiber Optic Patch Cable Singlemode Simplex."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/SingleMode SX/FC TO SC.jpg",
            "imageName":"FC TO SC",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik FC TO SC Fiber Optic Patch Cable Singlemode Simplex."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/SingleMode SX/FC TO FC.jpg",
            "imageName":"FC TO FC",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik FC TO FC Fiber Optic Patch Cable Singlemode Simplex."
        },
       
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/SingleMode SX/FC TO ST.jpg",
            "imageName":"FC TO ST",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik FC TO ST Fiber Optic Patch Cable Singlemode Simplex."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/SingleMode SX/ST TO ST.jpg",
            "imageName":"ST TO ST",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik ST TO ST Fiber Optic Patch Cable Singlemode Simplex."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/Singlemode  DX/LC TO LC.jpg",
            "imageName":"LC TO LC",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik LC TO LC Fiber Optic Patch Cable Singlemode duplex .",
            "productName":"Fiber Optic Patch Cable Singlemode Duplex"
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/Singlemode  DX/SC TO SC.jpg",
            "imageName":"SC TO SC",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik SC TO SC Fiber Optic Patch Cable Singlemode duplex."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/Singlemode  DX/ST TO ST.jpg",
            "imageName":"ST TO ST",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik ST TO ST Fiber Optic Patch Cable Singlemode duplex."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/Singlemode  DX/FCAPC TO FCAPC.jpg",
            "imageName":"FCAPC TO FCAPC",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik FCAPC TO FCAPC Fiber Optic Patch Cable Singlemode duplex."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/Multimode OM1/LC TO LC.jpg",
            "imageName":"LC TO LC",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik LC TO LC Fiber Optic Patch Cable Multimode OM1 Duplex .",
            "productName":"Fiber Optic Patch Cable Multimode OM1"
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/Multimode OM1/LC TO SC.jpg",
            "imageName":"LC TO SC",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik LC TO SC Fiber Optic Patch Cable Multimode OM1 Duplex ."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/Multimode OM1/LC TO ST.jpg",
            "imageName":"LC TO ST",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik LC TO ST Fiber Optic Patch Cable Multimode OM1 Duplex ."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/Multimode OM1/SC TO SC.jpg",
            "imageName":"SC TO SC",
            "class":"Fiber Optic Patch Cable",
            "content":"OpZonik SC TO SC Fiber Optic Patch Cable Multimode OM1 Duplex ."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/Multimode OM1/ST TO ST.jpg",
            "imageName":"ST TO ST",
            "class":"Fiber Optic Patch Cable",
            "content":"OpZonik ST TO ST Fiber Optic Patch Cable Multimode OM1 Duplex ."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/Multimode OM1/LC TO LC.jpg",
            "imageName":"LC TO LC",
            "class":"Fiber Optic Patch Cable",
            "content":"OpZonik LC TO LC Fiber Optic Patch Cable Multimode OM2 Duplex.",
            "productName":"Fiber Optic Patch Cable multimode OM2"
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/Multimode OM1/LC TO SC.jpg",
            "imageName":"LC TO SC",
            "class":"Fiber Optic Patch Cable",
            "content":"OpZonik LC TO SC Fiber Optic Patch Cable Multimode OM2 Duplex ."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/Multimode OM1/LC TO ST.jpg",
            "imageName":"LC TO ST",
            "class":"Fiber Optic Patch Cable",
            "content":"OpZonik LC TO ST Fiber Optic Patch Cable Multimode OM2 Duplex ."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/Multimode OM1/SC TO SC.jpg",
            "imageName":"SC TO SC",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik SC TO SC Fiber Optic Patch Cable Multimode OM2 Duplex ."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/Multimode OM1/ST TO ST.jpg",
            "imageName":"ST TO ST",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik ST TO ST Fiber Optic Patch Cable Multimode OM2 Duplex ."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/Multimode OM3/LC TO LC.jpg",
            "imageName":"LC TO LC",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik LC to LC Fiber Optic Patch Cable Multimode OM3 Duplex ",
            "productName":"Fiber Optic Patch Cable multimode OM3"
        },{
            "image":"../../public/productImage/Fiber Optic patch cabel/Multimode OM3/LC TO SC.jpg",
            "imageName":"LC TO SC",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik LC to SC Fiber Optic Patch Cable Multimode OM3 Duplex ."
        },{
            "image":"../../public/productImage/Fiber Optic patch cabel/Multimode OM3/SC TO SC.jpg",
            "imageName":"SC TO SC",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik SC to SC Fiber Optic Patch Cable Multimode OM3 Duplex ."
        },
        {
            "image":"../../public/productImage/Fiber Optic patch cabel/Multimode OM4/LC TO LC.jpg",
            "imageName":"LC TO LC",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik LC to LC Fiber Optic Patch Cable Multimode OM4 Duplex.",
            "productName":"Fiber Optic Patch Cable multimode OM4"
        },{
            "image":"../../public/productImage/Fiber Optic patch cabel/Multimode OM4/LC TO SC.jpg",
            "imageName":"LC TO SC",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik LC to SC Fiber Optic Patch Cable Multimode OM4 Duplex ."
        },{
            "image":"../../public/productImage/Fiber Optic patch cabel/Multimode OM4/SC TO SC.jpg",
            "imageName":"SC TO SC",
            "class":"Fiber_Optic_Patch_Cable",
            "content":"OpZonik SC to SC Fiber Optic Patch Cable Multimode OM4 Duplex ."
        },

  
 
    //ARMOURED CABLE
    {
        "image":"../../public/productImage/Armoured_Cable/LC TO SCAPC ARMOURED CABLE.jpg",
        "imageName":"LC TO SCAPC",
        "class":"Fiber_Optic_Patch_Cable_Armoured",
        "content":"OpZonik 1M SCAPC to LC Armoured Fiber Optic Patch Cable Single Mode Simplex.",
        "productName":"Fiber Optic Patch Cable Armoured"
    },
    {
        "image":"../../public/productImage/Armoured_Cable/SCAPC TO SCAPC ARMOURED CABLE.jpg",
        "imageName":"SCAPC TO SCAPC",
        "class":"Fiber_Optic_Patch_Cable_Armoured",
        "content":"OpZonik 1M SCAPC to SCAPC Armoured Fiber Optic Patch Cable Single Mode Simplex ."
    },
    // FIBER ADAPTOR CABLE
    {
        "image":"../../public/productImage/Adapter_Cables/LC TO SC S.MODE DX ADAPTER CABLE.jpg",
        "imageName":"LC TO SC",
        "class":"Fiber_Optic_Adapter_Cable",
        "content":"OpZonik 1FT LC to SC Fiber Optic Adapter Cable Singlemode .",
        "productName":"Fiber Optic Adapter Cable"
    },
    {
        "image":"../../public/productImage/Adapter_Cables/LC TO ST  S.MODE DX ADPTER CABLE.jpg",
        "imageName":"LC TO ST",
        "class":"Fiber_Optic_Adapter_Cable",
        "content":"OpZonik 1FT LC to ST Fiber Optic Adapter Cable Singlemode ."
    },
    {
        "image":"../../public/productImage/Adapter_Cables/LC TO SC M.MODE DX ADAPTER CABLE.jpg",
        "imageName":"LC TO SC",
        "class":"Fiber_Optic_Adapter_Cable",
        "content":"OpZonik 1FT LC to SC Fiber Optic Adapter Cable Multimode OM1 ."
    },
    {
        "image":"../../public/productImage/Adapter_Cables/LC TO ST M.MODE DX ADAPTER CABLE.jpg",
        "imageName":"LC TO ST",
        "class":"Fiber_Optic_Adapter_Cable",
        "content":"OpZonik 1FT LC to ST Fiber Optic Adapter Cable Multimode OM1 ."
    },

    // FIBER ADAPTER 
    {
        "image":"../../public/productImage/New Adapter/FC TO FC SX S.MODE.jpg",
        "imageName":"FC TO FC",
        "class":"Fiber_Optic_Adapter",
        "content":"OpZonik FC Female to FC Female Singlemode Simplex Fiber Optic Cable Adapter / Coupler",
        "productName":"Fiber Optic Adapter"
    },
    {
        "image":"../../public/productImage/New Adapter/ST TO ST SX S.MODE.jpg",
        "imageName":"ST TO ST",
        "class":"Fiber_Optic_Adapter",
        "content":"OpZonik ST Female to ST Female Singlemode Simplex Fiber Optic Cable Adapter / Coupler"
    },
    {
        "image":"../../public/productImage/New Adapter/SC S.MODE SX ADAPTER.jpg",
        "imageName":"SC TO SC",
        "class":"Fiber_Optic_Adapter",
        "content":"OpZonik SC Female to SC Female Singlemode Simplex Fiber Optic Cable Adapter / Coupler "
    },
    {
        "image":"../../public/productImage/New Adapter/SCAPC S.MODE SX ADAPTER.jpg",
        "imageName":"SCAPC TO SCAPC",
        "class":"Fiber_Optic_Adapter",
        "content":"OpZonik SCAPC Female to SCAPC Female Singlemode Simplex Fiber Optic Cable Adapter / Coupler "
    },
    {
        "image":"../../public/productImage/New Adapter/SC S.MODE DX ADAPTER.jpg",
        "imageName":"SC TO SC",
        "class":"Fiber_Optic_Adapter",
        "content":"OpZonik SC Female to SC Female Singlemode Duplex Fiber Optic Cable Adapter / Coupler"
    },
    {
        "image":"../../public/productImage/New Adapter/LC S.MODE DX ADAPTER.jpg",
        "imageName":"LC TO LC",
        "class":"Fiber_Optic_Adapter",
        "content":"OpZonik LC Female to LC Female APC Singlemode Duplex Fiber Optic Cable Adapter Coupler"
    },
    {
        "image":"../../public/productImage/New Adapter/SC TO SC SX M.MODE.jpg",
        "imageName":"SC TO SC",
        "class":"Fiber_Optic_Adapter",
        "content":"OpZonik SC Female to SC Female Multimode simplex Fiber Optic Cable Adapter / Coupler"
    },
  
    {
        "image":"../../public/productImage/New Adapter/SC M.MODE DX ADAPTER.jpg",
        "imageName":"SC TO SC",
        "class":"Fiber_Optic_Adapter",
        "content":"OpZonik SC Female to SC Female Multimode Duplex Fiber Optic Cable Adapter / Coupler "
    },
    {
        "image":"../../public/productImage/New Adapter/LC TO LC DX M.MODE.jpg",
        "imageName":"LC TO LC",
        "class":"Fiber_Optic_Adapter",
        "content":"OpZonik LC Female to LC Female Multimode Simplex Fiber Optic Cable Adapter / Coupler "
    },
    // FIBER HYBRID ADAPTER CABLE
    {
        "image":"../../public/productImage/fiber hybride adapter cable/fc-ls-hybride-adapter.jpg",
        "imageName":"FC-LC",
        "class":"Fiber_Optic_Hybrid_Adapter",
        "content":"FC-LC HYBRID FIBER OPTIC ADAPTER",
        "productName":"Fiber Optic Hybrid Adapter"
    },
   
    {
        "image":"../../public/productImage/fiber hybride adapter cable/sc-lc-hybride-adapter.jpg",
        "imageName":"SC-LC",
        "class":"Fiber_Optic_Hybrid_Adapter",
        "content":"SC-LC HYBRID FIBER OPTIC ADAPTER"
    },
   
    {
        "image":"../../public/productImage/fiber hybride adapter cable/sc-fc-hybride-adapter.jpg",
        "imageName":"SC-FC",
        "class":"Fiber_Optic_Hybrid_Adapter",
        "content":"SC-FC HYBRID FIBER OPTIC ADAPTER"
    },
    // ATENOUTOUR CABLE
    {
        "image":"../../public/productImage/fiber optics attenuators/sc.jpg",
        "imageName":"SC",
        "class":"Fiber_Optic_Attenuators",
        "content":"SC FIBER OPTIC ATTENUATORS",
        "productName":"Fiber Optic Attenuators"
            
    },  
    {
        "image":"../../public/productImage/fiber optics attenuators/lc.jpg",
        "imageName":"LC",
        "class":"Fiber_Optic_Attenuators",
        "content":"LC FIBER OPTIC ATTENUATORS"
    },
    //PIGTAILS CABLE
    {
        "image":"../../public/productImage/Pigtail/LC FIBER OPTIC PIGTAIL S.MODE 12 CORE.jpg",
        "imageName":"LC",
        "class":"Multifiber_Pigtails",
        "content":"OpZonik 1.5M 12 Strand Singlemode 9/125um LC Fiber optic pigtails.",
        "productName":"Multifiber Pigtail"
    }, 
    {
        "image":"../../public/productImage/Pigtail/SC FIBER OPTIC PIGTAIL S.MODE 12 CORE.jpg",
        "imageName":"SC",
        "class":"Multifiber_Pigtails",
        "content":"OpZonik 1.5M 12 Strand Singlemode 9/125um SC Fiber optic pigtails."
    },
    {
        "image":"../../public/productImage/Pigtail/om1_new.jpg",
        "imageName":"OM1",
        "class":"Multifiber_Pigtails",
        "content":"OpZonik 1.5M 12 Strand Multimode OM1 62.5/125um SC Fiber optic pigtails."
    },
    {
        "image":"../../public/productImage/Pigtail/MULTIMODE OM1  PIGTAILS.jpg",
        "imageName":"OM2",
        "class":"Multifiber Pigtails",
        "content":"OpZonik 1.5M 12 Strand Multimode OM1 62.5/125um ST Fiber optic pigtails."
    },
    {
        "image":"../../public/productImage/Pigtail/MULTIMODE OM 3 LC.jpg",
        "imageName":"OM3",
        "class":"Multifiber_Pigtails",
        "content":"OpZonik 1.5M 12 Strand Multimode OM3 50/125um LC Fiber optic pigtails."
    },

    // BREAKOUT CABLE
    {
        "image":"../../public/productImage/breakout cable/48breakout.jpg",
        "imageName":"48 BREAKOUT",
        "class":"Breakout_Cable",
        "content":"48 FIBER INDOOR BREAKOUT CABLE",
        "productName":"Breakout Cable"
    },

    // RACKOUNT CABLE

    {
        "image":"../../public/productImage/rackmount cable/LC Rack Encl Cat3/1.jpg",
        "imageName":"LC",
        "class":"Fiber_Optic_Rackmount_Enclosure",
        "content":"OpZonik 1U Fiber Optic Rackmount Enclosure, 24 Port LC Duplex Singlemode Fiber Optic Patch panel.",
        "productName":"Fiber Optic Rackmount Enclosure"
    },
    {
        "image":"../../public/productImage/rackmount cable/SC Rack Enclosure Cat3/2.jpg",
        "imageName":"SC",
        "class":"Fiber_Optic_Rackmount_Enclosure",
        "content":"OpZonik 1U Fiber Optic Rackmount Enclosure, 24 Port SC Singlemode Fiber Optic Patch panel"
    },

    //loopback adaptor test cable
    {
        "image":"../../public/productImage/loopback adapter test cable/sc.jpg",
        "imageName":"SC",
        "class":"Loopback_Adapter_Test_Cable",
        "content":"SC LOOPBACK ADAPTER TEST CABLE",
        "productName":"Loopback adapter test cable"
    },
    {
        "image":"../../public/productImage/loopback adapter test cable/lc.jpg",
        "imageName":"LC",
        "class":"Loopback_Adapter_Test_Cable",
        "content":"LC LOOPBACK ADAPTER TEST CABLE"
    },


   

]                   

module.exports={product:productButton,productimg:productImage}